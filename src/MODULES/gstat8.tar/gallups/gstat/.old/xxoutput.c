/*
 * This is the output module
 * Contains specialized functions to output select adn combo
 * question. It also contains functions for graphic tables
 *
 */

#include <stdio.h>
#include <stdlib.h>
#include <math.h>

#include "gallups.h"
#include "gstat.h"

#define BARCHAR	"�"

treekey_t INTmask;
char tempstr[16384];
char colstr[20];
int WIDTH=60;


char *strndup(char *s, int c, size_t size)
{
	memset(s, c, size);
	s[size]='\0';

  return s;
}


void dump_select_options(void)
{
  int *fields;
  int i, sum=0;
  treekey_t key;

	fields = malloc(sizeof(int) * qseldatacnt(curquest));
	for(i=0;i<fields[i];i++)fields[i]=0;

	key_set(INTmask, 1, 0, 0);

	printf(tem_data[TEMH_O].template);
	  
	/* key[1,x,y] is the options, sum up for x and y and print results */
	for(i=0;i<qseldatacnt(curquest);i++) {
		key_set(key, i);
		fields[i] = class_sum(key, INTmask);
		sum+=fields[i];
//		printf("Option %s\t==> %i\n", qseldataidx(curquest)[i], sum);
	}

	for(i=0;i<qseldatacnt(curquest);i++) {
		printf(tem_data[TEMT_O].template, i+1, fields[i], sum, fields[i] * 100.0 / sum);
		
//		printf("%i | %2i/%2i   %5.2f |\n", i, fields[i], sum, fields[i] * 100.0 / sum);
	}

	printf(tem_data[TEMF_O].template);
//	printf("%s\n", strndup(tempstr, '-', WIDTH));
	
	free(fields);
}


void dump_select_options_sex(void)
{
  int *fields;
  int i, sum=0;
  treekey_t key;

//	analyze();

	fields = malloc(sizeof(int) * qseldatacnt(curquest) * 2);
	for(i=0;i<fields[i];i++)fields[i]=0;

	key_set(INTmask, 1, 1, 0);
	  
	printf(tem_data[TEMH_OS].template);

	/* key[1,x,y] is the options, sum up for x and y and print results */
	for(i=0;i<qseldatacnt(curquest);i++) {
		key_set(key, i, 0);
		fields[i*2] = class_sum(key, INTmask);

		key_set(key, i, 1);
		fields[i*2+1] = class_sum(key, INTmask);
		
		sum+=fields[2*i] + fields[i*2+1];
//		printf("Option %s\t==> %i\n", qseldataidx(curquest)[i], sum);
	}

	for(i=0;i<qseldatacnt(curquest);i++) {
		printf(tem_data[TEMT_OS].template, i+1, fields[i*2], sum, fields[2*i] * 100.0 / sum,
				fields[i*2+1], sum, fields[2*i+1] * 100.0 / sum);

	}
	
	printf(tem_data[TEMF_OS].template);

	free(fields);
}

#define OAF(n)	fields[i*jl+n], fields[i*jl+n] * 100.0 / sum

void dump_select_options_age(void)
{
  int *fields;
  int i, j, jl, sum=0, psum;
  treekey_t key;

//	analyze();


	class_handlers[2](CMD_SIZE, &jl);

	fields = calloc(qseldatacnt(curquest) * (jl+1), sizeof(int));
//	for(i=0;i<fields[i];i++)fields[i]=0;

	key_set(INTmask, 1, 0, 1);
	key[0] = handler_count;
		  
	/* key[1,x,y] is the options, sum up for x and y and print results */
	for(i=0;i<qseldatacnt(curquest);i++) {
		key[1] = i;

		for(j=0;j<jl;j++) {
			key[3] = j;

			fields[i*jl+j] = class_sum(key, INTmask);
		
			sum+=fields[i*jl+j];
		}

//		printf("Option %s\t==> %i\n", qseldataidx(curquest)[i], sum);
	}

	WIDTH=70;

//	printf("%3s|", "");
//	for(j=0;j<jl;j++)printf(" %3i-%-3i|", j*10, j*10+9);
//	printf("\n%s\n", strndup(tempstr, '-', WIDTH));

	printf(tem_data[TEMH_OA].template);
	
	for(i=0;i<qseldatacnt(curquest);i++) {
//		printf("%3i|", i);

		psum = 0;
		for(j=0;j<jl;j++) {
//			printf("%3i %3.0f%%|", fields[i*jl+j], fields[i*jl+j] * 100.0 / sum);
			psum += fields[i*jl+j];
		}
//		printf("%3i %3.0f%%\n", psum, psum * 100.0 / sum);

		printf(tem_data[TEMT_OA].template, i+1, OAF(0), OAF(1), OAF(2), OAF(3), OAF(4), OAF(5));
	}

	printf(tem_data[TEMF_OA].template);
	
	free(fields);
}






void chart_select_options(void)
{
  int *fields;
  int i, j, sum=0, n;
  treekey_t key;

//	analyze();

	fields = malloc(sizeof(int) * qseldatacnt(curquest));
	for(i=0;i<fields[i];i++)fields[i]=0;

	key_set(INTmask, 1, 0, 0);
  
	/* key[1,x,y] is the options, sum up for x and y and print results */
	for(i=0;i<qseldatacnt(curquest);i++) {
		key_set(key, i);
		fields[i] = class_sum(key, INTmask);
		sum+=fields[i];
	}

	strndup(tempstr, '-', WIDTH);
	printf(tem_data[TEMGH_O].template, tempstr);

	for(i=0;i<qseldatacnt(curquest);i++) {
//		printf("%-15s |", qseldataidx(curquest)[i]);
		j = floor((WIDTH * fields[i] / sum) + 0.5);
//		printf("j=%i\n", j);
		tempstr[0]='\0';
		
		strcat(tempstr, "[0;1;31m");
//		printf("[0;1;31m");
		
		n=WIDTH;
		for(;j>0;j--,n--)strcat(tempstr, BARCHAR);
		for(;n>0;n--)strcat(tempstr, " ");
		
		strcat(tempstr, "[0m");

		printf(tem_data[TEMGT_O].template, i+1, tempstr, fields[i], 100.0 * fields[i] / sum);
		
//		printf("%3i|%s|%3i %3.0f%%|\n", i+1, tempstr, fields[i], 100.0 * fields[i] / sum);
	}

	strndup(tempstr, '-', WIDTH);
	printf(tem_data[TEMGF_O].template, tempstr);
	
	free(fields);
}

void chart_select_options_sex(void)
{
  int *fields;
  int i, j, jj, sum=0, n, psum;
  treekey_t key;

//	analyze();

	fields = malloc(sizeof(int) * qseldatacnt(curquest) * 2);
	for(i=0;i<fields[i];i++)fields[i]=0;

	key_set(INTmask, 1, 1, 0);
  
	/* key[1,x,y] is the options, sum up for x and y and print results */
	for(i=0;i<qseldatacnt(curquest);i++) {
		key_set(key, i, 0);
		fields[2*i] = class_sum(key, INTmask);
		
		key_set(key, i, 1);
		fields[2*i+1] = class_sum(key, INTmask);
		
		sum+=fields[2*i] + fields[2*i+1];
	}

	strndup(tempstr, '-', WIDTH);
	printf(tem_data[TEMGH_OS].template, tempstr);

	for(i=0;i<qseldatacnt(curquest);i++) {
//		printf("%-15s |", qseldataidx(curquest)[i]);
		tempstr[0]='\0';
		n = WIDTH;
		strcat(tempstr, "[0;1m");

		for(jj=0;jj<2;jj++) {
			sprintf(colstr, "[3%im", 1+jj);
			strcat(tempstr, colstr);

			j = floor((WIDTH * fields[2*i+jj] / sum) + 0.5);
			for(;j>0;j--,n--)strcat(tempstr, BARCHAR);
		}

		for(;n>0;n--)strcat(tempstr, " ");

		strcat(tempstr, "[0m");
//		printf("%s\n", tempstr);

		psum = 0;
		for(jj=0;jj<2;jj++)psum += fields[i*2+jj];
			
		printf(tem_data[TEMGT_OS].template, i+1, tempstr, psum, 100.0 * psum / sum);
//		printf("%3i|%s|%3i %3.0f%%|\n", i+1, tempstr, psum, 100.0 * psum / sum);

	}

	strndup(tempstr, '-', WIDTH);
	printf(tem_data[TEMGF_OS].template, tempstr);
	
	free(fields);
}

void chart_select_options_age(void)
{
  int *fields, n;
  int i, j, jl, jj, sum=0, psum;
  treekey_t key;

	class_handlers[2](CMD_SIZE, &jl);

	fields = calloc(qseldatacnt(curquest) * (jl+1), sizeof(int));

	key_set(INTmask, 1, 0, 1);
	key[0] = handler_count;
		  
	/* key[1,x,y] is the options, sum up for x and y and print results */
	for(i=0;i<qseldatacnt(curquest);i++) {
		key[1] = i;

		for(j=0;j<jl;j++) {
			key[3] = j;

			fields[i*jl+j] = class_sum(key, INTmask);
		
			sum+=fields[i*jl+j];
		}
	}
	
	strndup(tempstr, '-', WIDTH);
	printf(tem_data[TEMGH_OA].template, tempstr);

	for(i=0;i<qseldatacnt(curquest);i++) {
		tempstr[0]='\0';
		n = WIDTH;
		strcat(tempstr, "[0;1m");

		psum = 0;
		for(j=0;j<jl;j++) {
			sprintf(colstr, "[3%im", j+1);
			strcat(tempstr, colstr);
			jj = floor((WIDTH * fields[i*jl+j] / sum) + 0.5);
			for(;jj>0;jj--,n--)strcat(tempstr, BARCHAR);
			psum+=fields[i*jl+j];
		}

		for(;n>0;n--)strcat(tempstr, " ");
		
		strcat(tempstr, "[0m");

		printf(tem_data[TEMGT_OA].template, i+1, tempstr, psum, 100.0 * psum / sum);
		
//		printf("%s\n", tempstr);
	}

	strndup(tempstr, '-', WIDTH);
	printf(tem_data[TEMGF_OA].template, tempstr);
	
#if 0
	printf("Field explanation\n");
	for(j=0;j<jl;j++) {
		if(!(j%4))printf("\n");
		sprintf(colstr, "[1;3%im", j+1);
		strcpy(tempstr, colstr);
		strcat(tempstr, BARCHAR);strcat(tempstr, BARCHAR);strcat(tempstr, BARCHAR);
		strcat(tempstr, "[0m");
		printf("%s %3i-%-3i  ", tempstr, j*10 , j*10+9);
	}
	printf("\n");
#endif

	free(fields);
}
