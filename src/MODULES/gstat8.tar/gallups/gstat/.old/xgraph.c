/*
 * module to create graphic charts
 *
 */

#include <stdio.h>
#include <stdlib.h>
#include <math.h>

#include "gallups.h"
#include "gstat.h"

#define BARCHAR	"�"

treekey_t INTmask;

char tempstr[16384];
char colstr[20];
int WIDTH=60;


void chart_select_options(void)
{
  int *fields;
  int i, j, sum=0, n;
  treekey_t key;

//	analyze();

	fields = malloc(sizeof(int) * qseldatacnt(curquest));
	for(i=0;i<fields[i];i++)fields[i]=0;

	key_set(INTmask, 1, 0, 0);
  
	/* key[1,x,y] is the options, sum up for x and y and print results */
	for(i=0;i<qseldatacnt(curquest);i++) {
		key_set(key, i);
		fields[i] = class_sum(key, INTmask);
		sum+=fields[i];
	}



	for(i=0;i<qseldatacnt(curquest);i++) {
//		printf("%-15s |", qseldataidx(curquest)[i]);
		j = floor((WIDTH * fields[i] / sum) + 0.5);
//		printf("j=%i\n", j);
		tempstr[0]='\0';
		
		strcat(tempstr, "[0;31m");
//		printf("[0;1;31m");
		
		n=WIDTH;
		for(;j>0;j--,n--)strcat(tempstr, BARCHAR);
		for(;n>0;n--)strcat(tempstr, " ");
		
		strcat(tempstr, "[0m");

		printf("%3i|%s|%3i %3.0f%%|\n", i+1, tempstr, fields[i], 100.0 * fields[i] / sum);
	}
	
	free(fields);
}

void chart_select_options_sex(void)
{
  int *fields;
  int i, j, jj, sum=0, n, psum;
  treekey_t key;

//	analyze();

	fields = malloc(sizeof(int) * qseldatacnt(curquest) * 2);
	for(i=0;i<fields[i];i++)fields[i]=0;

	key_set(INTmask, 1, 1, 0);
  
	/* key[1,x,y] is the options, sum up for x and y and print results */
	for(i=0;i<qseldatacnt(curquest);i++) {
		key_set(key, i, 0);
		fields[2*i] = class_sum(key, INTmask);
		
		key_set(key, i, 1);
		fields[2*i+1] = class_sum(key, INTmask);
		
		sum+=fields[2*i] + fields[2*i+1];
	}

	for(i=0;i<qseldatacnt(curquest);i++) {
//		printf("%-15s |", qseldataidx(curquest)[i]);
		tempstr[0]='\0';
		n = WIDTH;
		strcat(tempstr, "[0;1m");

		for(jj=0;jj<2;jj++) {
			sprintf(colstr, "[3%im", 1+jj);
			strcat(tempstr, colstr);

			j = floor((WIDTH * fields[2*i+jj] / sum) + 0.5);
			for(;j>0;j--,n--)strcat(tempstr, BARCHAR);
		}

		for(;n>0;n--)strcat(tempstr, " ");

		strcat(tempstr, "[0m");
//		printf("%s\n", tempstr);

		psum = 0;
		for(jj=0;jj<2;jj++)psum += fields[i*2+jj];
			
		printf("%3i|%s|%3i %3.0f%%|\n", i+1, tempstr, psum, 100.0 * psum / sum);

	}

	
	free(fields);
}

void chart_select_options_age(void)
{
  int *fields;
  int i, j, jl, jj, sum=0;
  treekey_t key;

	class_handlers[2](CMD_SIZE, &jl);

	fields = calloc(qseldatacnt(curquest) * (jl+1), sizeof(int));

	key_set(INTmask, 1, 0, 1);
	key[0] = handler_count;
		  
	/* key[1,x,y] is the options, sum up for x and y and print results */
	for(i=0;i<qseldatacnt(curquest);i++) {
		key[1] = i;

		for(j=0;j<jl;j++) {
			key[3] = j;

			fields[i*jl+j] = class_sum(key, INTmask);
		
			sum+=fields[i*jl+j];
		}
	}

	for(i=0;i<qseldatacnt(curquest);i++) {
		printf("%-15s |", qseldataidx(curquest)[i]);
		tempstr[0]='\0';
		strcat(tempstr, "[0;1m");
		
		for(j=0;j<jl;j++) {
			sprintf(colstr, "[3%im", j+1);
			strcat(tempstr, colstr);
			jj = floor((WIDTH * fields[i*jl+j] / sum) + 0.5);
			for(;jj>0;jj--)strcat(tempstr, BARCHAR);
			
		}
		strcat(tempstr, "[0m");
		printf("%s\n", tempstr);
	}

	printf("Field explanation\n");
	for(j=0;j<jl;j++) {
		if(!(j%4))printf("\n");
		sprintf(colstr, "[1;3%im", j+1);
		strcpy(tempstr, colstr);
		strcat(tempstr, BARCHAR);strcat(tempstr, BARCHAR);strcat(tempstr, BARCHAR);
		strcat(tempstr, "[0m");
		printf("%s %3i-%-3i  ", tempstr, j*10 , j*10+9);
	}
	printf("\n");
	
	free(fields);
}
