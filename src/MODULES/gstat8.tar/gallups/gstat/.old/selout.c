/*
 * This is the output module
 *
 * Contains specialized functions to output select questions.
 * It also contains functions for graphic tables.
 *
 */

#include <stdio.h>
#include <stdlib.h>
#include <math.h>

#include "gallups.h"
#include "gstat.h"

#define BARCHAR	"�"

treekey_t INTmask;
char tempstr[16384];
char colstr[20];

struct curargs CA;


#if 1


void dump_select(int flag)
{
  int i, ii, j;
  treekey_t key;
  int jj, k, jl, jll;
  int siz0, siz1, siz2, siz3=1;

	class_handlers[0](CMD_SIZE, &siz0);
	class_handlers[1](CMD_SIZE, &siz1);
	class_handlers[2](CMD_SIZE, &siz2);
	
	switch(flag) {
		case FL_OPT: key_set(INTmask, 1, 0, 0); break;
		case FL_OPTSEX: key_set(INTmask, 1, 1, 0); break;
		case FL_OPTAGE: key_set(INTmask, 1, 0, 1); break;
		case FL_OPTSEXAGE: key_set(INTmask, 1, 1, 1); break;
	}
	
	if(qtyp(curquest) == GQ_COMBO) {
		class_handlers[3](CMD_SIZE, &siz3);

		INTmask[0]++;
		INTmask[4] = 1;
	}
	
	switch(flag) {
		case FL_OPT:
			alloc_ca(siz0 * siz3, 1);
			for(i=0;i<siz0;i++) {
				key[1] = i;
				if(qtyp(curquest) == GQ_COMBO) {
					for(ii=0;ii<siz3;ii++)
						CA.fields[i*siz3+ii] = class_sum(key, INTmask);
				} else
					CA.fields[i] = class_sum(key, INTmask);
			}
			gather_ca(siz0 * siz3, 1);
			break;
			
		case FL_OPTSEX:
			alloc_ca(siz0 * siz3, siz1);

			for(i=0;i<siz0;i++) {
				key[1] = i;
				
				for(j=0;j<siz1;j++) {
					key[2] = j;
					if(qtyp(curquest) == GQ_COMBO) {
						for(ii=0;ii<siz3;ii++)
							CA.fields[(i*siz3+ii)*siz1+j] = class_sum(key, INTmask);
					} else
 						CA.fields[i*siz1+j] = class_sum(key, INTmask);
				}
			}
			gather_ca(siz0 * siz3, siz1);
			break;
				
		case FL_OPTAGE:
			alloc_ca(siz0 * siz3, siz2);
			for(i=0;i<siz0;i++) {
				key[1] = i;
				for(j=0;j<siz2;j++) {
					key[3] = j;
					if(qtyp(curquest) == GQ_COMBO) {
						for(ii=0;i<siz3;ii++)
							CA.fields[(i*siz3+ii)*siz2+j] = class_sum(key, INTmask);
					} else
						CA.fields[ i*siz2+j ] = class_sum(key, INTmask);
				}
			}
			gather_ca(siz0 * siz3, siz2);
			break;
			
		case FL_OPTSEXAGE:
			alloc_ca(siz0 * siz3 * siz1, siz2);
			for(i=0;i<siz0;i++) {
				key[1] = i;
				for(j=0;j<siz1;j++) {
					key[2] = j;
					for(jj=0;jj<siz2;jj++) {
						key[3] = jj;
						if(qtyp(curquest) == GQ_COMBO) {
							for(ii=0;ii<siz3;ii++)
								CA.fields[((i*siz3+ii)*siz1+j)*siz2+jj] = class_sum(key, INTmask);
						} else
							CA.fields[(i*siz1+j)*siz2+jj] = class_sum(key, INTmask);
					}
				}
			}
			gather_ca(siz0 * siz3 * siz1, siz2);
			break;
	}

	switch(flag) {
		case FL_OPT: printf(tem_data[ TEMH_SO ].template); break;
		case FL_OPTSEX: printf(tem_data[ TEMH_SOS ].template); break;
		case FL_OPTAGE: printf(tem_data[ TEMH_SOA ].template); break;
		case FL_OPTSEXAGE: printf(tem_data[ TEMH_SOSA ].template); break;
	}		


	for(i=0;i<siz0;i++) {
		switch(flag) {
			case FL_OPT: load_ca(i, i*siz3, i*siz3*siz1, 0); break;
			case FL_OPTSEX: load_ca(i, i*siz3*siz1, i*siz3, 0); break;
			case FL_OPTAGE: load_ca(i, i*siz3*siz2, i*siz3, 0); break;
			case FL_OPTSEXAGE: load_ca(i, i*siz3*siz1*siz2, i*siz3*siz1, 0); break;
		}
		
		if(qtyp(curquest) == GQ_COMBO)
			printf("---- %1.85F ---\n");

		switch(flag) {
			case FL_OPT: printf(tem_data[ TEMT_SO ].template); break;
			case FL_OPTSEX: printf(tem_data[ TEMT_SOS ].template); break;
			case FL_OPTAGE: printf(tem_data[ TEMT_SOA ].template); break;
			case FL_OPTSEXAGE: printf(tem_data[ TEMT_SOSA ].template); break;
		}
	}

	load_ca(0, 0, 0, 0);
	switch(flag) {
		case FL_OPT: printf(tem_data[ TEMF_SO ].template); break;
		case FL_OPTSEX: printf(tem_data[ TEMF_SOS ].template); break;
		case FL_OPTAGE: printf(tem_data[ TEMF_SOA ].template); break;
		case FL_OPTSEXAGE: printf(tem_data[ TEMF_SOSA ].template); break;
	}

	free_ca();
}


#endif











void dump_select_options(void)
{
  int i;
  treekey_t key;

	alloc_ca(qseldatacnt(curquest), 1);
	key_set(INTmask, 1, 0, 0);

	printf(tem_data[TEMH_SO].template);
	for(i=0;i<qseldatacnt(curquest);i++) {
		key_set(key, i);
		CA.fields[i] = class_sum(key, INTmask);
	}

	gather_ca(qseldatacnt(curquest), 1);
	for(i=0;i<qseldatacnt(curquest);i++) {
		load_ca(i, i, i, 0);
		printf(tem_data[TEMT_SO].template);
	}

	load_ca(0, 0, 0, 0);
	printf(tem_data[TEMF_SO].template);
	free_ca();
}

void dump_select_options_sex(void)
{
  int i, j, jl;
  treekey_t key;

	class_handlers[1](CMD_SIZE, &jl);
	alloc_ca(qseldatacnt(curquest), jl);
	key_set(INTmask, 1, 1, 0);
	  
	printf(tem_data[TEMH_SOS].template);
	for(i=0;i<qseldatacnt(curquest);i++) {
		key[1] = i;
		for(j=0;j<jl;j++) {
			key[2] = j;
			CA.fields[i*jl+j] = class_sum(key, INTmask);
		}
	}

	gather_ca(qseldatacnt(curquest), jl);
	for(i=0;i<qseldatacnt(curquest);i++) {
		load_ca(i, i*jl, i, 0);
		printf(tem_data[ TEMT_SOS ].template);
	}
	
	load_ca(0, 0, 0, 0);
	printf(tem_data[TEMF_SOS].template);
	free_ca();
}

void dump_select_options_age(void) {
  int i, j, jl;
  treekey_t key;

	class_handlers[2](CMD_SIZE, &jl);
	alloc_ca(qseldatacnt(curquest), jl);
	
	key_set(INTmask, 1, 0, 1);
	key[0] = handler_count;
	for(i=0;i<qseldatacnt(curquest);i++) {
		key[1] = i;
		for(j=0;j<jl;j++) {
			key[3] = j;
			CA.fields[i*jl+j] = class_sum(key, INTmask);
		}
	}

	gather_ca(qseldatacnt(curquest), jl);
	printf(tem_data[TEMH_SOA].template);
	for(i=0;i<qseldatacnt(curquest);i++) {
		load_ca(i, i*jl, i, 0);
		printf(tem_data[TEMT_SOA].template);
	}

	load_ca(0, 0, 0, 0);
	printf(tem_data[TEMF_SOA].template);
	free_ca();
}

void dump_select_options_sex_age(void)
{
  int i, j, n, jl, jll;
  treekey_t key;
	
	class_handlers[1](CMD_SIZE, &jl);		// sex handler
	class_handlers[2](CMD_SIZE, &jll);		// age handler
	alloc_ca(qseldatacnt(curquest) * jl, jll);

	key_set(INTmask, 1, 1, 1);
	key[0] = handler_count;
	for(i=0;i<qseldatacnt(curquest);i++) {
		key[1] = i;
		for(j=0;j<jl;j++) {
			key[2] = j;
			for(n=0;n<jll;n++) {
				key[3] = n;
				CA.fields[(i*jl+j)*jll+n] = class_sum(key, INTmask);
			}
		}
	}

	gather_ca(qseldatacnt(curquest) * jl, jll);
	printf(tem_data[TEMH_SOSA].template);
	for(i=0;i<qseldatacnt(curquest);i++) {
		load_ca(i, i*jl*jll, i*jl, 0);
		printf(tem_data[ TEMT_SOSA ].template);
	}

	load_ca(0, 0, 0, 0);
	printf(tem_data[TEMF_SOSA].template);
	free_ca();
}







/* charts */

	
void chart_select_options(void)
{
  int i, j, n;
  treekey_t key;

	alloc_ca(qseldatacnt(curquest), 1);

	key_set(INTmask, 1, 0, 0);
  
	/* key[1,x,y] is the options, sum up for x and y and print results */
	for(i=0;i<qseldatacnt(curquest);i++) {
		key_set(key, i);
		CA.fields[i] = class_sum(key, INTmask);
	}

	gather_ca(qseldatacnt(curquest), 1);

	printf(tem_data[TEMGH_SO].template);

	for(i=0;i<qseldatacnt(curquest);i++) {
		load_ca(i, i, i, 0);
		
		j = floor((WIDTH * CA.fields[i] / CA.row_t_sum) + 0.5);

		tempstr[0]='\0';
		strcat(tempstr, "[0;1;31m");
		n=WIDTH;
		for(;j>0;j--,n--)strcat(tempstr, BARCHAR);
		for(;n>0;n--)strcat(tempstr, " ");
		strcat(tempstr, "[0m");

		printf(tem_data[TEMGT_SO].template, tempstr);
	}

	load_ca(0, 0, 0, 0);
	printf(tem_data[TEMGF_SO].template);
	
	free_ca();
}

void chart_select_options_sex(void)
{
  int i, j, jl, jj, n;
  treekey_t key;

	class_handlers[1](CMD_SIZE, &jl);

	alloc_ca(qseldatacnt(curquest), jl);

	key_set(INTmask, 1, 1, 0);
  
	for(i=0;i<qseldatacnt(curquest);i++) {
		key[1] = i;
		for(j=0;j<jl;j++) {
			key[2] = j;
			CA.fields[i*jl+j] = class_sum(key, INTmask);
		}
	}

	gather_ca(qseldatacnt(curquest), jl);

	printf(tem_data[TEMGH_SOS].template);

	for(i=0;i<qseldatacnt(curquest);i++) {
		load_ca(i, i*jl, i, 0);
		
		tempstr[0]='\0';
		n = WIDTH;
		strcat(tempstr, "[0;1m");
		for(jj=0;jj<jl;jj++) {
			sprintf(colstr, "[3%im", 1+jj);
			strcat(tempstr, colstr);

			j = floor((WIDTH * CA.fields[jl*i+jj] / CA.row_t_sum) + 0.5);
			for(;j>0;j--,n--)strcat(tempstr, BARCHAR);
		}


/* there might be a differnce to the actual size of the bar beacuse of the
   roundings for the same row sum. The difference (if it exists), is always
   equal to 1. So add one more bar character of the last color. Of course this
   is not right. I'd prefer a white bar between the two colors or at the beginning.
   ANW */
   
		if(WIDTH - n < (WIDTH * CA.row_p_sum[i] / CA.row_t_sum)) {
#if 1
			strcat(tempstr, BARCHAR);
			n--;
#else
			sprintf(colstr, "[0;1;37m%s", BARCHAR);
			memmove(tempstr+strlen(colstr), tempstr, strlen(tempstr)+1);
			memcpy(tempstr, colstr, strlen(colstr));
			n--;
#endif
		}

		for(;n>0;n--)strcat(tempstr, " ");
		strcat(tempstr, "[0m");
			
		printf(tem_data[ TEMGT_SOS ].template, tempstr);
	}

	load_ca(0, 0, 0, 0);
	printf(tem_data[TEMGF_SOS].template);
	
	free_ca();
}

void chart_select_options_age(void)
{
  int i, j, jl, jj, n;
  treekey_t key;

	class_handlers[2](CMD_SIZE, &jl);

	alloc_ca(qseldatacnt(curquest), jl);

	key_set(INTmask, 1, 0, 1);
	key[0] = handler_count;
		  
	/* key[1,x,y] is the options, sum up for x and y and print results */
	for(i=0;i<qseldatacnt(curquest);i++) {
		key[1] = i;

		for(j=0;j<jl;j++) {
			key[3] = j;
			CA.fields[i*jl+j] = class_sum(key, INTmask);
		}
	}

	gather_ca(qseldatacnt(curquest), jl);
	
	printf(tem_data[TEMGH_SOA].template);

	for(i=0;i<qseldatacnt(curquest);i++) {
		load_ca(i, i*jl, i, 0);
		
		tempstr[0]='\0';
		n = WIDTH;
		strcat(tempstr, "[0;1m");
		for(j=0;j<jl;j++) {
			sprintf(colstr, "[3%im", j+1);
			strcat(tempstr, colstr);
			jj = floor((WIDTH * CA.fields[i*jl+j] / CA.row_t_sum) + 0.5);
			for(;jj>0;jj--,n--)strcat(tempstr, BARCHAR);
		}

		for(;n>0;n--)strcat(tempstr, " ");
		strcat(tempstr, "[0m");


		printf(tem_data[ TEMGT_SOA ].template, tempstr);
	}

	load_ca(0, 0, 0, 0);
	printf(tem_data[TEMGF_SOA].template);
	
	free_ca();
}

void chart_select_options_sex_age(void)
{
  int i, j, k, jl, jll, jj, n;
  treekey_t key;
  char *s[2];

	class_handlers[1](CMD_SIZE, &jl);
	class_handlers[2](CMD_SIZE, &jll);
	alloc_ca(qseldatacnt(curquest) * jl, jll);
	key_set(INTmask, 1, 1, 1);
	key[0] = handler_count;
	for(i=0;i<qseldatacnt(curquest);i++) {
		key[1] = i;
		
		for(j=0;j<jl;j++) {
			key[2] = j;
			
			for(n=0;n<jll;n++) {
				key[3] = n;
				
				CA.fields[(i*jl+j)*jll+n] = class_sum(key, INTmask);
			}
		}
	}
	
	gather_ca(qseldatacnt(curquest) * jl, jll);


	printf(tem_data[TEMGH_SOSA].template);

	s[0] = tempstr;
	s[1] = &tempstr[8192];
		
	for(i=0;i<qseldatacnt(curquest);i++) {
		load_ca(i, i*jl*jll, i*jl, 0);
		
		for(k=0;k<jl;k++) {

			s[k][0]='\0';
			n = WIDTH;
			strcat(s[k], "[0;1m");
	
			for(j=0;j<jll;j++) {
				sprintf(colstr, "[3%im", j+1);
				strcat(s[k], colstr);
				jj = floor((WIDTH * CA.fields[(i*jl+k)*jll+j] / CA.row_t_sum) + 0.5);
				for(;jj>0;jj--,n--)strcat(s[k], BARCHAR);
			}

			for(;n>0;n--)strcat(s[k], " ");
			strcat(s[k], "[0m");
		}

		printf(tem_data[ TEMGT_SOSA ].template, s[0], s[1]);
	}

	load_ca(0, 0, 0, 0);
	printf(tem_data[TEMGF_SOSA].template);
	
	free_ca();
}
