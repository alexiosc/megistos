/*
 * This is the output module
 * Contains specialized functions to output select adn combo
 * question. It also contains functions for graphic tables
 *
 */

#include <stdio.h>
#include <stdlib.h>
#include <math.h>

#include "gallups.h"
#include "gstat.h"

#define BARCHAR	"�"

treekey_t INTmask;
char tempstr[16384];
char colstr[20];
int WIDTH=60;

struct curargs CA;


void load_ca(copt, cfld, crow, ccol)
{
	CA.curoption = copt;
	CA.curfield = cfld;
	CA.currow = crow;
	CA.curcol = ccol;
}


char *strndup(char *s, int c, size_t size)
{
	memset(s, c, size);
	s[size]='\0';

  return s;
}

void alloc_ca(int size, int elem)
{
  int i;

	CA.fields = malloc(size * elem * sizeof(int));
	for(i=0;i<size*elem;i++)CA.fields[i] = 0;
	
	CA.row_p_sum = malloc(size * sizeof(int));
	for(i=0;i<size;i++)CA.row_p_sum[i] = 0;
	
	CA.col_p_sum = malloc(elem * sizeof(int));
	for(i=0;i<elem;i++)CA.col_p_sum[i] = 0;

	CA.col_t_sum = CA.row_t_sum = 0;
	CA.curfield = CA.curoption = CA.currow = CA.curcol = 0;
}

void free_ca(void)
{
	free(CA.fields);
	free(CA.col_p_sum);
	free(CA.row_p_sum);
}


void gather_ca(int rows, int cols)
{
  int i, j;

	for(i=0;i<rows;i++)
		for(j=0;j<cols;j++) {
			CA.row_p_sum[i] += CA.fields[cols * i + j];
			CA.col_p_sum[j] += CA.fields[cols * i + j];
		}
	for(i=0;i<rows;i++)
		CA.col_t_sum += CA.row_p_sum[i];
	
	for(j=0;j<cols;j++)
		CA.row_t_sum += CA.col_p_sum[j];
}


	
			
void dump_select_options(void)
{
  int i;
  treekey_t key;

	alloc_ca(qseldatacnt(curquest), 1);

	key_set(INTmask, 1, 0, 0);

	printf(tem_data[TEMH_O].template);
	  
	/* key[1,x,y] is the options, sum up for x and y and print results */
	for(i=0;i<qseldatacnt(curquest);i++) {
		key_set(key, i);
		CA.fields[i] = class_sum(key, INTmask);
	}

	gather_ca(qseldatacnt(curquest), 1);
	
	for(i=0;i<qseldatacnt(curquest);i++) {
		load_ca(i, i, i, 0);
		printf(tem_data[TEMT_O].template);
	}

	load_ca(0, 0, 0, 0);
	printf(tem_data[TEMF_O].template);
	free_ca();
}



void dump_select_options_sex(void)
{
  int i, j, jl;
  treekey_t key;


	class_handlers[1](CMD_SIZE, &jl);
	alloc_ca(qseldatacnt(curquest), jl);

	key_set(INTmask, 1, 1, 0);
	  
	printf(tem_data[TEMH_OS].template);

	/* key[1,x,y] is the options, sum up for x and y and print results */
	for(i=0;i<qseldatacnt(curquest);i++) {
		key[1] = i;
		for(j=0;j<jl;j++) {
			key[2] = j;
			CA.fields[i*jl+j] = class_sum(key, INTmask);
		}
	}

	gather_ca(qseldatacnt(curquest), jl);

	for(i=0;i<qseldatacnt(curquest);i++) {
		load_ca(i, i*jl, i, 0);
		printf(tem_data[ TEMT_OS ].template);
	}
	
	load_ca(0, 0, 0, 0);
	printf(tem_data[TEMF_OS].template);
	free_ca();
}

#define OAF(n)	fields[i*jl+n], fields[i*jl+n] * 100.0 / sum

void dump_select_options_age(void) {
  int i, j, jl;
  treekey_t key;

	class_handlers[2](CMD_SIZE, &jl);

	alloc_ca(qseldatacnt(curquest), jl);
	

	key_set(INTmask, 1, 0, 1);
	key[0] = handler_count;
		  
	/* key[1,x,y] is the options, sum up for x and y and print results */
	for(i=0;i<qseldatacnt(curquest);i++) {
		key[1] = i;

		for(j=0;j<jl;j++) {
			key[3] = j;
			CA.fields[i*jl+j] = class_sum(key, INTmask);
		}
	}

	gather_ca(qseldatacnt(curquest), jl);

	printf(tem_data[TEMH_OA].template);
	
	for(i=0;i<qseldatacnt(curquest);i++) {
		load_ca(i, i*jl, i, 0);

		printf(tem_data[TEMT_OA].template);
	}

	load_ca(0, 0, 0, 0);
	printf(tem_data[TEMF_OA].template);
	
	free_ca();
}




void dump_select_options_sex_age(void)
{
  int i, j, n, jl, jll;
  treekey_t key;

	
	class_handlers[1](CMD_SIZE, &jl);		// sex handler
	class_handlers[2](CMD_SIZE, &jll);		// age handler

	alloc_ca(qseldatacnt(curquest) * jl, jll);


	key_set(INTmask, 1, 1, 1);
	key[0] = handler_count;
		  
	/* key[1,x,y] is the options, sum up for x and y and print results */
	for(i=0;i<qseldatacnt(curquest);i++) {
		key[1] = i;

		for(j=0;j<jl;j++) {
			key[2] = j;
			
			for(n=0;n<jll;n++) {
				key[3] = n;
				
				CA.fields[(i*jl+j)*jll+n] = class_sum(key, INTmask);
			}
		}
	}

	gather_ca(qseldatacnt(curquest) * jl, jll);

	printf(tem_data[TEMH_OSA].template);
	
	for(i=0;i<qseldatacnt(curquest);i++) {
		load_ca(i, i*jl*jll, i*jl, 0);
		printf(tem_data[ TEMT_OSA ].template);
	}

	load_ca(0, 0, 0, 0);
	printf(tem_data[TEMF_OSA].template);
	
	free_ca();
}







/* charts */

	
void chart_select_options(void)
{
  int i, j, n;
  treekey_t key;

	alloc_ca(qseldatacnt(curquest), 1);

	key_set(INTmask, 1, 0, 0);
  
	/* key[1,x,y] is the options, sum up for x and y and print results */
	for(i=0;i<qseldatacnt(curquest);i++) {
		key_set(key, i);
		CA.fields[i] = class_sum(key, INTmask);
	}

	gather_ca(qseldatacnt(curquest), 1);

	printf(tem_data[TEMGH_O].template);

	for(i=0;i<qseldatacnt(curquest);i++) {
		load_ca(i, i, i, 0);
		
		j = floor((WIDTH * CA.fields[i] / CA.row_t_sum) + 0.5);

		tempstr[0]='\0';
		strcat(tempstr, "[0;1;31m");
		n=WIDTH;
		for(;j>0;j--,n--)strcat(tempstr, BARCHAR);
		for(;n>0;n--)strcat(tempstr, " ");
		strcat(tempstr, "[0m");

		printf(tem_data[TEMGT_O].template, tempstr);
	}

	load_ca(0, 0, 0, 0);
	printf(tem_data[TEMGF_O].template);
	
	free_ca();
}

void chart_select_options_sex(void)
{
  int i, j, jl, jj, n;
  treekey_t key;

	class_handlers[1](CMD_SIZE, &jl);

	alloc_ca(qseldatacnt(curquest), jl);

	key_set(INTmask, 1, 1, 0);
  
	for(i=0;i<qseldatacnt(curquest);i++) {
		key[1] = i;
		for(j=0;j<jl;j++) {
			key[2] = j;
			CA.fields[i*jl+j] = class_sum(key, INTmask);
		}
	}

	gather_ca(qseldatacnt(curquest), jl);

	printf(tem_data[TEMGH_OS].template);

	for(i=0;i<qseldatacnt(curquest);i++) {
		load_ca(i, i*jl, i, 0);
		
		tempstr[0]='\0';
		n = WIDTH;
		strcat(tempstr, "[0;1m");
		for(jj=0;jj<jl;jj++) {
			sprintf(colstr, "[3%im", 1+jj);
			strcat(tempstr, colstr);

			j = floor((WIDTH * CA.fields[jl*i+jj] / CA.row_t_sum) + 0.5);
			for(;j>0;j--,n--)strcat(tempstr, BARCHAR);
		}


/* there might be a differnce to the actual size of the bar beacuse of the
   roundings for the same row sum. The difference (if it exists), is always
   equal to 1. So add one more bar character of the last color. Of course this
   is not right. I'd prefer a white bar between the two colors or at the beginning.
   ANW */
   
		if(WIDTH - n < (WIDTH * CA.row_p_sum[i] / CA.row_t_sum)) {
#if 1
			strcat(tempstr, BARCHAR);
			n--;
#else
			sprintf(colstr, "[0;1;37m%s", BARCHAR);
			memmove(tempstr+strlen(colstr), tempstr, strlen(tempstr)+1);
			memcpy(tempstr, colstr, strlen(colstr));
			n--;
#endif
		}

		for(;n>0;n--)strcat(tempstr, " ");
		strcat(tempstr, "[0m");
			
		printf(tem_data[ TEMGT_OS ].template, tempstr);
	}

	load_ca(0, 0, 0, 0);
	printf(tem_data[TEMGF_OS].template);
	
	free_ca();
}

void chart_select_options_age(void)
{
  int i, j, jl, jj, n;
  treekey_t key;

	class_handlers[2](CMD_SIZE, &jl);

	alloc_ca(qseldatacnt(curquest), jl);

	key_set(INTmask, 1, 0, 1);
	key[0] = handler_count;
		  
	/* key[1,x,y] is the options, sum up for x and y and print results */
	for(i=0;i<qseldatacnt(curquest);i++) {
		key[1] = i;

		for(j=0;j<jl;j++) {
			key[3] = j;
			CA.fields[i*jl+j] = class_sum(key, INTmask);
		}
	}

	gather_ca(qseldatacnt(curquest), jl);
	
	printf(tem_data[TEMGH_OA].template);

	for(i=0;i<qseldatacnt(curquest);i++) {
		load_ca(i, i*jl, i, 0);
		
		tempstr[0]='\0';
		n = WIDTH;
		strcat(tempstr, "[0;1m");
		for(j=0;j<jl;j++) {
			sprintf(colstr, "[3%im", j+1);
			strcat(tempstr, colstr);
			jj = floor((WIDTH * CA.fields[i*jl+j] / CA.row_t_sum) + 0.5);
			for(;jj>0;jj--,n--)strcat(tempstr, BARCHAR);
		}

		for(;n>0;n--)strcat(tempstr, " ");
		strcat(tempstr, "[0m");


		printf(tem_data[ TEMGT_OA ].template, tempstr);
	}

	load_ca(0, 0, 0, 0);
	printf(tem_data[TEMGF_OA].template);
	
	free_ca();
}

void chart_select_options_sex_age(void)
{
  int i, j, k, jl, jll, jj, n;
  treekey_t key;
  char *s[2];

	class_handlers[1](CMD_SIZE, &jl);
	class_handlers[2](CMD_SIZE, &jll);
	alloc_ca(qseldatacnt(curquest) * jl, jll);
	key_set(INTmask, 1, 1, 1);
	key[0] = handler_count;
	for(i=0;i<qseldatacnt(curquest);i++) {
		key[1] = i;
		
		for(j=0;j<jl;j++) {
			key[2] = j;
			
			for(n=0;n<jll;n++) {
				key[3] = n;
				
				CA.fields[(i*jl+j)*jll+n] = class_sum(key, INTmask);
			}
		}
	}
	
	gather_ca(qseldatacnt(curquest) * jl, jll);


	printf(tem_data[TEMGH_OSA].template);

	s[0] = tempstr;
	s[1] = &tempstr[8192];
		
	for(i=0;i<qseldatacnt(curquest);i++) {
		load_ca(i, i*jl*jll, i*jl, 0);
		
		for(k=0;k<jl;k++) {

			s[k][0]='\0';
			n = WIDTH;
			strcat(s[k], "[0;1m");
	
			for(j=0;j<jll;j++) {
				sprintf(colstr, "[3%im", j+1);
				strcat(s[k], colstr);
				jj = floor((WIDTH * CA.fields[(i*jl+k)*jll+j] / CA.row_t_sum) + 0.5);
				for(;jj>0;jj--,n--)strcat(s[k], BARCHAR);
			}

			for(;n>0;n--)strcat(s[k], " ");
			strcat(s[k], "[0m");
		}

		printf(tem_data[ TEMGT_OSA ].template, s[0], s[1]);
	}

	load_ca(0, 0, 0, 0);
	printf(tem_data[TEMGF_OSA].template);
	
	free_ca();
}
