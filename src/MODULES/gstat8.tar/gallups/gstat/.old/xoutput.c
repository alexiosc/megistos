/*
 * This is the output module
 * Contains specialized functions to output select adn combo
 * question. It also contains functions for graphic tables
 *
 */

#include <stdio.h>
#include <stdlib.h>

#include "gallups.h"
#include "gstat.h"

char *template[1024];
char tempstr[1024];

treekey_t INTmask;

char *strndup(char *s, int c, size_t size)
{
	memset(s, c, size);
	s[size]='\0';

  return s;
}


void xdump_select_options(void)
{
  int *fields;
  int i, sum=0;
  treekey_t key;

	fields = malloc(sizeof(int) * qseldatacnt(curquest));
	for(i=0;i<fields[i];i++)fields[i]=0;

	key_set(INTmask, 1, 0, 0);

	printf("%s\n", strndup(tempstr, '-', WIDTH));
	  
	/* key[1,x,y] is the options, sum up for x and y and print results */
	for(i=0;i<qseldatacnt(curquest);i++) {
		key_set(key, i);
		fields[i] = class_sum(key, INTmask);
		sum+=fields[i];
//		printf("Option %s\t==> %i\n", qseldataidx(curquest)[i], sum);
	}

	for(i=0;i<qseldatacnt(curquest);i++) {
		printf("%i | %2i/%2i   %5.2f |\n", i, fields[i], sum, fields[i] * 100.0 / sum);
	}

	printf("%s\n", strndup(tempstr, '-', WIDTH));
	
	free(fields);
}

void dump_select_options(void)
{
  int *fields;
  int i, sum=0;
  treekey_t key;

	fields = malloc(sizeof(int) * qseldatacnt(curquest));
	for(i=0;i<fields[i];i++)fields[i]=0;

	key_set(INTmask, 1, 0, 0);

	printf(tem_data[TEMH_O].template);
	  
	/* key[1,x,y] is the options, sum up for x and y and print results */
	for(i=0;i<qseldatacnt(curquest);i++) {
		key_set(key, i);
		fields[i] = class_sum(key, INTmask);
		sum+=fields[i];
//		printf("Option %s\t==> %i\n", qseldataidx(curquest)[i], sum);
	}

	for(i=0;i<qseldatacnt(curquest);i++) {
		printf(tem_data[TEMT_O].template, i+1, fields[i], sum, fields[i] * 100.0 / sum);
		
//		printf("%i | %2i/%2i   %5.2f |\n", i, fields[i], sum, fields[i] * 100.0 / sum);
	}

	printf(tem_data[TEMF_O].template);
//	printf("%s\n", strndup(tempstr, '-', WIDTH));
	
	free(fields);
}


void dump_select_options_sex(void)
{
  int *fields;
  int i, sum=0;
  treekey_t key;

//	analyze();

	fields = malloc(sizeof(int) * qseldatacnt(curquest) * 2);
	for(i=0;i<fields[i];i++)fields[i]=0;

	key_set(INTmask, 1, 1, 0);
	  
	/* key[1,x,y] is the options, sum up for x and y and print results */
	for(i=0;i<qseldatacnt(curquest);i++) {
		key_set(key, i, 0);
		fields[i*2] = class_sum(key, INTmask);

		key_set(key, i, 1);
		fields[i*2+1] = class_sum(key, INTmask);
		
		sum+=fields[2*i] + fields[i*2+1];
//		printf("Option %s\t==> %i\n", qseldataidx(curquest)[i], sum);
	}

	for(i=0;i<qseldatacnt(curquest);i++) {
		printf("%-30s   M	%2i/%2i   %4.2f\n", qseldataidx(curquest)[i], fields[i*2], sum, fields[2*i] * 100.0 / sum);
		printf("%-30s   F	%2i/%2i   %4.2f\n", ""/*qseldataidx(curquest)[i]*/, fields[i*2+1], sum, fields[2*i+1] * 100.0 / sum);
	}
	
	free(fields);
}

void dump_select_options_age(void)
{
  int *fields;
  int i, j, jl, sum=0, psum;
  treekey_t key;

//	analyze();


	class_handlers[2](CMD_SIZE, &jl);

	fields = calloc(qseldatacnt(curquest) * (jl+1), sizeof(int));
//	for(i=0;i<fields[i];i++)fields[i]=0;

	key_set(INTmask, 1, 0, 1);
	key[0] = handler_count;
		  
	/* key[1,x,y] is the options, sum up for x and y and print results */
	for(i=0;i<qseldatacnt(curquest);i++) {
		key[1] = i;

		for(j=0;j<jl;j++) {
			key[3] = j;

			fields[i*jl+j] = class_sum(key, INTmask);
		
			sum+=fields[i*jl+j];
		}

//		printf("Option %s\t==> %i\n", qseldataidx(curquest)[i], sum);
	}

	WIDTH=70;

	printf("%3s|", "");
	for(j=0;j<jl;j++)printf(" %3i-%-3i|", j*10, j*10+9);
	printf("\n%s\n", strndup(tempstr, '-', WIDTH));

	for(i=0;i<qseldatacnt(curquest);i++) {
		printf("%3i|", i);

		psum = 0;
		for(j=0;j<jl;j++) {
			printf("%3i %3.0f%%|", fields[i*jl+j], fields[i*jl+j] * 100.0 / sum);
			psum += fields[i*jl+j];
//			printf("%-30s   %i	%2i/%2i   %4.2f\n", qseldataidx(curquest)[i], j*10, fields[i*jl+j], sum, fields[i*jl+j] * 100.0 / sum);
		}
		printf("%3i %3.0f%%\n", psum, psum * 100.0 / sum);
	}

	
	free(fields);
}
